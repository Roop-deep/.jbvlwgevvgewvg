﻿namespace WebApplication1.Services
{
    public class JSONService
    {
    }
}
